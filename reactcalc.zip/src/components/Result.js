import '../css/style.css'


const Result=({value})=>{
    
    return (
        <>
            <div className="component-display">
                <div>{value}</div>
            </div>
        </>
    );
}
export default Result;